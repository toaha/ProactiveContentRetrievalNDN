/* -*- Mode:C++; c-file-style:"gnu"; indent-tabs-mode:nil; -*- */
/**
 * Copyright (c) 2011-2015  Regents of the University of California.
 *
 * This file is part of ndnSIM. See AUTHORS for complete list of ndnSIM authors and
 * contributors.
 *
 * ndnSIM is free software: you can redistribute it and/or modify it under the terms
 * of the GNU General Public License as published by the Free Software Foundation,
 * either version 3 of the License, or (at your option) any later version.
 *
 * ndnSIM is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
 * without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
 * PURPOSE.  See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along with
 * ndnSIM, e.g., in COPYING.md file.  If not, see <http://www.gnu.org/licenses/>.
 **/

//#include <Python.h>
#include "voi-calculation.hpp"
#include "ns3/log.h"
#include "ns3/assert.h"
#include "ns3/packet.h"
#include "ns3/uinteger.h"
#include "ns3/integer.h"
#include "ns3/double.h"
#include "ns3/math.h"
#include <cmath>
#include "math.h"
#include "ns3/log.h"
#include <vector>
#include <algorithm>
#include <iterator>
#include <cmath>
#include <functional>
#include <algorithm>
#include <stdint.h>
#include <utility>
#include <queue>
#include <stdio.h>
#include <stdlib.h>
#include <iostream>
#include <fstream>

//#include <stdio.h>      /* printf */
//#include <math.h>       /* atan2 */

#include "model/ndn-l3-protocol.hpp"
#include "model/ndn-app-link-service.hpp"
#include "model/null-transport.hpp"

NS_LOG_COMPONENT_DEFINE("ndn.VoICalcu");

// int Num_of_Vehicles = 5; ----------------------------------.-.-.-..-.-.-.-.-.-.-.--..-.-.-.--.-..-.-.--.-.-.-.-.-.-..
// int Content_Numbers = 50; ---------------------------------_+_+_+_+_+++++++++++++++++++++++++++++++++++++++++++++++++
#define PI 3.14159265
#define N 5;

#define ProdUcer 0;

namespace ns3 {
namespace ndn {

uint32_t	m_nNode; // number of nodes
uint32_t	m_nSeq; // number of nodes
double_t	m_nTime; // number of nodes

uint32_t	m_Cou_Seq[60][50]; // [Nodes][Content]

double_t	m_Current_Time_Seq_ID[60][50]; // [Nodes][Content]
double_t	m_Previous_Time_Seq_ID[60][50]; // [Nodes][Content]

double_t 	Voi_NodeID_linear[60][50]; // [Nodes][Content]
double_t 	Voi_NodeID_Exponential[60][50]; // [Nodes][Content]
double_t 	Voi_NodeID_Logrithamic[60][50]; // [Nodes][Content]

double_t    nodeLocatOld[3][60];
double_t    nodeLocatNew[3][60];

double_t    nodeVelocity[3][60];

double_t 	Yi[60][50];
double_t 	Zi[60][50];

double 		distanceBetweenVehicles[60][60];
double 		directionOfMotion[60][60];
double 		relativeSpeed[60][60];
double 		cacheAvailability[60][60];
double 		distance[60][60];

double 		m_I_time[60][50]; //For Calculating Delay


double X11[50], Y11[50], P_Correlation[60][60];


int 		RecommendM[60]; //Sequence  Number of Recommended Message

//void VoI_Calc::getDataFromNode(uint32_t nNode, uint32_t nSeq, double nTime, double x, double y, double z)
//{
//	m_nNode = nNode;
//	m_nSeq = nSeq;
//	m_nTime = nTime;
//
//	DataFromNode(m_nNode, m_nSeq, m_nTime);
//}

template <typename T> class Vector2D
{
private:
    T x;
    T y;

public:
    explicit Vector2D(const T& x=0, const T& y=0) : x(x), y(y) {}
    Vector2D(const Vector2D<T>& src) : x(src.x), y(src.y) {}
    virtual ~Vector2D() {}

    // Accessors
    inline T X() const { return x; }
    inline T Y() const { return y; }
    inline T X(const T& x) { this->x = x; }
    inline T Y(const T& y) { this->y = y; }

    // Vector arithmetic
    inline Vector2D<T> operator-() const
        { return Vector2D<T>(-x, -y); }

    inline Vector2D<T> operator+() const
        { return Vector2D<T>(+x, +y); }

    inline Vector2D<T> operator+(const Vector2D<T>& v) const
        { return Vector2D<T>(x+v.x, y+v.y); }

    inline Vector2D<T> operator-(const Vector2D<T>& v) const
        { return Vector2D<T>(x-v.x, y-v.y); }

    inline Vector2D<T> operator*(const T& s) const
        { return Vector2D<T>(x*s, y*s); }

    // Dot product
    inline T operator*(const Vector2D<T>& v) const
        { return x*v.x + y*v.y; }

    // l-2 norm
    inline T norm() const { return sqrt(x*x + y*y); }

    // inner angle (radians)
    static T angle(const Vector2D<T>& v1, const Vector2D<T>& v2)
    {
        return acos( (v1 * v2) / (v1.norm() * v2.norm()) );
    }
};


void VoI_Calc::getDataFromNode(uint32_t nNode, uint32_t nSeq, double nTime, double x, double y, double z, double x10, double y10, double z10)
{
		m_nNode = nNode;
		m_nSeq = nSeq;
		m_nTime = nTime;

//		Location Update
		nodeLocatOld[0][m_nNode] = nodeLocatNew[0][m_nNode];
		nodeLocatOld[1][m_nNode] = nodeLocatNew[1][m_nNode];
		nodeLocatOld[2][m_nNode] = nodeLocatNew[2][m_nNode];

		nodeLocatNew[0][m_nNode] = x;
		nodeLocatNew[1][m_nNode] = y;
		nodeLocatNew[2][m_nNode] = z;

		nodeVelocity[0][m_nNode] = x10;
		nodeVelocity[1][m_nNode] = y10;
		nodeVelocity[2][m_nNode] = z10;

//	for (int i=0;i<60;i++)
//	{
//		 std::cout<<" "<< nodeLocatOld[0][i]<<" "<< nodeLocatOld[1][i]<<" "<< nodeLocatOld[2][i]<<" -- "<< m_nNode <<" " << m_nSeq <<"\n";
//         std::cout<<" "<< nodeLocatNew[0][i]<<" "<< nodeLocatNew[1][i]<<" "<< nodeLocatNew[2][i]<<" -- "<< m_nNode <<" " << m_nSeq <<"\n \n";
//	}
//		std::cout <<"\n 0.5 m_Cou_Seq [m_nNode][m_nSeq] = "<< m_Cou_Seq [m_nNode][m_nSeq];
//		std::cout <<"\n 0.5 m_Cou_Seq [0][2] = "<< m_Cou_Seq [0][2] <<"\n";

		m_Cou_Seq [m_nNode][m_nSeq] = m_Cou_Seq [m_nNode][m_nSeq] +1 ;
//		std::cout <<"\n 0 m_Cou_Seq [m_nNode][m_nSeq] = "<< m_Cou_Seq [m_nNode][m_nSeq];
//		std::cout <<"\n 0 m_Cou_Seq [0][2] = "<< m_Cou_Seq [0][2] <<"\n";

		if(m_Cou_Seq [m_nNode][m_nSeq] == 1)
		{
//			std::cout <<"\n 1 m_Cou_Seq [m_nNode][m_nSeq] = "<< m_Cou_Seq [m_nNode][m_nSeq];
//			std::cout <<"\n 1 m_Cou_Seq [0][2] = "<< m_Cou_Seq [0][2] <<"\n";

			m_Previous_Time_Seq_ID [m_nNode][m_nSeq] = m_nTime;
		}
		else
		{
//			std::cout <<"\n 2 m_Cou_Seq [m_nNode][m_nSeq] = "<< m_Cou_Seq [m_nNode][m_nSeq];
//			std::cout <<"\n 2 m_Cou_Seq [0][2] = "<< m_Cou_Seq [0][2] <<"\n";
			m_Previous_Time_Seq_ID [m_nNode][m_nSeq] = m_Current_Time_Seq_ID [m_nNode][m_nSeq];
		}
		m_Current_Time_Seq_ID [m_nNode][m_nSeq] = m_nTime;

		Yi[m_nNode][m_nSeq] = (double)(m_Current_Time_Seq_ID [m_nNode][m_nSeq]/1000000) - (double)(m_Previous_Time_Seq_ID [m_nNode][m_nSeq]/1000000) ;

//		Voi_NodeID_Exponential [VehNum][ContetNum]

		for (int i = 0; i<60; i++)
			{
			for (int i1 = 0; i1<51; i1++)
				{
				Zi[i][i1] = (double)(m_nTime/1000000) - (double)(m_Current_Time_Seq_ID[i][i1]/1000000);
				Voi_NodeID_linear [i][i1] = (0.5)*((1/(1+(Yi[i][i1] /m_Cou_Seq[i][i1])))+(1/(1+(Zi[i][i1]/m_Cou_Seq[i][i1]))));
				Voi_NodeID_Exponential [i][i1] = (0.5)*((exp(-Yi[i][i1] /m_Cou_Seq[i][i1]))+(exp(-Zi[i][i1]/m_Cou_Seq[i][i1])));
				Voi_NodeID_Logrithamic [i][i1] = (0.5)*((1/log2((Yi[i][i1] /m_Cou_Seq[i][i1])+2))+(1/log2((Zi[i][i1]/m_Cou_Seq[i][i1])+2)));

//				std::cout <<"\n Voi_NodeID_linear [i][i1] = "<<Voi_NodeID_linear [i][i1] <<" Voi_NodeID_linear [i][i1] = "<<Voi_NodeID_linear [i][i1] <<" Voi_NodeID_Logrithamic [i][i1] = "<<Voi_NodeID_Logrithamic [i][i1] <<"\n";
				}
			}

		for (int i = 0; i<60; i++)
			{
			for (int i1 = 0; i1<51; i1++)
				{

				if(isnan(Voi_NodeID_linear [i][i1]))
				{
					Voi_NodeID_linear [i][i1] = 0;
				}

				if(isnan(Voi_NodeID_linear [i][i1]))
				{
					Voi_NodeID_linear [i][i1] = 0;
				}
				if(isnan(Voi_NodeID_linear [i][i1]))
				{
					Voi_NodeID_linear [i][i1] = 0;
				}

//				std::cout <<"\n Voi_NodeID_linear [i][i1] = "<<Voi_NodeID_linear [i][i1] <<" Voi_NodeID_linear [i][i1] = "<<Voi_NodeID_linear [i][i1] <<" Voi_NodeID_linear [i][i1] = "<<Voi_NodeID_linear [i][i1] <<"\n";
				}
			}



		int n = 50;
		for (int i1 = 0; i1<60; i1++)
			{
				for(int i=0;i<51;i++)
					{
						X11[i] = Voi_NodeID_linear [i1][i]; /////////////////////////////////////////////////////////////////
					}
				for(int i2 = 0; i2<60; i2++ )
					{
						for(int i=0;i<50;i++)
							{
								Y11[i] = Voi_NodeID_linear [i2][i];//////////////////////////////////////////////////////////////
							}
						P_Correlation[i1] [i2]= CorrelationCoefficient(X11, Y11, n);
					}
			}

		for(int i=0;i<60;i++)
		{
			for(int j=0;j<60;j++)
			{
				if(isnan(P_Correlation [i][j]))
				{
					P_Correlation [i][j] = -1;
				}
				if(i==j)
				{
					P_Correlation [i][j] = 0;
				}
			}
		}


		double maxVal = 0;
		int corrVeh = -1;
		for(int i=0;i<60;i++)
		{
//			std::cout <<" "<< P_Correlation [i][m_nNode] <<" ";
			if (P_Correlation [i][m_nNode] > maxVal)
				{
					maxVal = P_Correlation [i][m_nNode];
					corrVeh = i;
				}
		}

std::cout <<"\n <---- Recommended Vehicle Correlation ----> "<< maxVal <<"\n";
std::cout <<" <---- Recommended Vehicle for ----> "<< m_nNode <<" is " << corrVeh <<"\n";


 //		Voi_NodeID_linear [VehNum][ContetNum]
		double VoISeq = Voi_NodeID_linear [corrVeh][m_nSeq];//////////////////////////////////////////////////////
		double VoIDiff = 1;
		int RecContent = -1;
		for(int i=1;i<51;i++)
		{
			double	diffmod = sqrt( pow((VoISeq - Voi_NodeID_linear [corrVeh][i]),2));////////////////////////////////////////
			double	diffexact = VoISeq - Voi_NodeID_linear [corrVeh][i];///////////////////////////////////////////////////////

			if ((diffexact < 0)&& (diffmod < VoIDiff))
				{
					VoIDiff = diffmod;
					RecContent = i;
				}
		}


		 std::cout <<"\n <---- Recommended Vehicle Correlation ----> "<< maxVal <<"\n";
		 std::cout <<" <---- Recommended Vehicle for ----> "<< m_nNode <<" is " << corrVeh <<"\n";
		 std::cout <<" <---- Next Recommended Content for ----> "<< m_nSeq <<" is " << RecContent <<"\n";
		 std::cout <<" <---- VoIDiff ----> is " << VoIDiff <<"\n";

		if(RecContent==-1)
		{
			for(int i=1;i<51;i++)
			{
				double	diffmod = sqrt( pow((VoISeq - Voi_NodeID_linear [corrVeh][i]),2));///////////////////////////

				if ((diffmod < VoIDiff)&& (i != m_nSeq))
					{
						VoIDiff = diffmod;
						RecContent = i;
					}
			}
		}


		 std::cout <<"\n <---- Recommended Vehicle Correlation ----> "<< maxVal <<"\n";
		 std::cout <<" <---- Recommended Vehicle for ----> "<< m_nNode <<" is " << corrVeh <<"\n";
		 std::cout <<" <---- Next Recommended Content for ----> "<< m_nSeq <<" is " << RecContent <<"\n";
		 std::cout <<" <---- VoIDiff ----> is " << VoIDiff <<"\n";

//		for(int i=0;i<60;i++)
//		{
//			for(int j=0;j<60;j++)
//			{
//			// std::cout << P_Correlation [i][j] <<" ";
//			}
//			// std::cout <<"\n";
//		}


//------------------*****************************__________________
//		Distance From Consumer Calculation:

		double distance_from_consumer[60];
		double max,min;
		max = -1;
		min = 1000000;
		for (int i=1;i<60;i++)
		{
			// std::cout << "distance_from_consumer[i]=" << distance_from_consumer[i]<<std::endl;
			distance_from_consumer[i] = sqrt( pow((nodeLocatNew[0][m_nNode]-nodeLocatNew[0][i]),2) + pow((nodeLocatNew[1][m_nNode]-nodeLocatNew[1][i]),2)+ pow((nodeLocatNew[2][m_nNode]-nodeLocatNew[2][i]),2));

			if(max < distance_from_consumer[i])
			{
				max = distance_from_consumer[i];
			}

			if((min > distance_from_consumer[i])&&(m_nNode != i))
			{
				min = distance_from_consumer[i];
			}
//			 std::cout << "distance_from_consumer[i]=" << distance_from_consumer[i] << " min " << min << " max " << max <<std::endl;
		}

		double scaled_distance_from_consumer[60];
		for (int i=1;i<60;i++)
		{
//			std::cout << "distance_from_consumer[i]=" << distance_from_consumer[i]<<std::endl;
			scaled_distance_from_consumer[i] = (max - distance_from_consumer[i]) /(max - min);
			// std::cout << "scaled_distance_from_consumer[i]=" << scaled_distance_from_consumer[i]<<std::endl;
		}
		scaled_distance_from_consumer[m_nNode] = 0;
		scaled_distance_from_consumer[0] = 0;

		// std::cout << std::endl;
//		for (int i=0;i<60;i++)
//			{
//					std::cout << "scaled_distance_from_consumer[i]=" << scaled_distance_from_consumer[i]<<std::endl;
//			}

//------------------*****************************__________________
//		Velocity Of Consumer Calculation:
		double Velocity_difference_consumer[60];
		max = -1;
		min = 1000000;
		for (int i=1;i<60;i++)
			{
	//			// std::cout << "Velocity_difference_consumer[i]=" << Velocity_difference_consumer[i]<<std::endl;
				Velocity_difference_consumer[i] = sqrt( pow((nodeVelocity[0][m_nNode]-nodeVelocity[0][i]),2) + pow((nodeVelocity[1][m_nNode]-nodeVelocity[1][i]),2)+ pow((nodeVelocity[2][m_nNode]-nodeVelocity[2][i]),2));
//				std::cout << "Velocity_difference_consumer[i]=" << Velocity_difference_consumer[i]<<std::endl;
					if(max < Velocity_difference_consumer[i])
					{
						max = Velocity_difference_consumer[i];
					}
					if((min > Velocity_difference_consumer[i])&&(m_nNode != i))
					{
						min = Velocity_difference_consumer[i];
					}
//					std::cout << "Velocity_difference_consumer[i]=" << Velocity_difference_consumer[i] << " min " << min << " max " << max <<std::endl;
			}


		double scaled_velocity_difference_from_consumer[60];
		for (int i=1;i<60;i++)
			{
	//			// std::cout << "scaled_velocity_difference_from_consumer[i]=" << distance_from_consumer[i]<<std::endl;
//			scaled_velocity_difference_from_consumer[i] = 1 /scaled_velocity_difference_from_consumer[i];
			scaled_velocity_difference_from_consumer[i] = (max-Velocity_difference_consumer[i])/(max - min);
				// std::cout << " ----> scaled_velocity_difference_from_consumer[i]=" << scaled_velocity_difference_from_consumer[i]<<std::endl;
			}
			scaled_velocity_difference_from_consumer[m_nNode] = 0;
			scaled_velocity_difference_from_consumer[0] = 0; //Producer

//			std::cout << std::endl;

//		for (int i=0;i<60;i++)
//			{
//					 std::cout << "scaled_velocity_difference_from_consumer[i]=" << scaled_velocity_difference_from_consumer[i]<<std::endl;
//			}

		//------------------*****************************__________________
//		Angle of Motion Calculation

		double Angle[60];
		for (int i=1;i<60;i++)
		{
			double p1x,p1y,p2x,p2y,p3x,p3y;

			p1x = nodeLocatOld[0][i];
			p1y = nodeLocatOld[1][i];

			// std::cout<<" "<< nodeLocatOld[0][i]<<" "<< nodeLocatOld[1][i] <<" -- "<< m_nNode <<" " << m_nSeq <<"\n";
			// std::cout<<" "<< nodeLocatNew[0][i]<<" "<< nodeLocatNew[1][i] <<" -- "<< m_nNode <<" " << m_nSeq <<"\n";

		    // std::cout <<" i "<< i <<" \t p1x[i] = " << p1x << std::endl;
		    // std::cout <<" i "<< i <<" \t p1y[i] = " << p1y << std::endl;

			p2x = nodeLocatOld[0][i]+1000;
			p2y = nodeLocatOld[1][i];

		    // std::cout <<" i "<< i <<" \t p2x[i] = " << p2x << std::endl;
		    // std::cout <<" i "<< i <<" \t p2y[i] = " << p2y << std::endl;

			p3x = nodeLocatNew[0][i];
			p3y = nodeLocatNew[1][i];

		    // std::cout <<" i "<< i <<" \t p3x[i] = " << p3x << std::endl;
		    // std::cout <<" i "<< i <<" \t p3y[i] = " << p3y << std::endl;

		    Vector2D<double> p1(p1x,p1y); // Vertax of intersection OR Point of Intersection
		    Vector2D<double> p2(p2x,p2y);
		    Vector2D<double> p3(p3x,p3y);

		    double rad = Vector2D<double>::angle(p2-p1, p3-p1);
		    double deg = rad * 160.0 / M_PI;

		    // std::cout << "\t Rad[i] = " << rad << std::endl;
		    Angle[i] = deg;
		    // std::cout << "\t Angle[i] = " << Angle[i] << std::endl;
		}

		double Difference_Angle[60];
		max = -1;
		min = 1000000;
		for (int i=1;i<60;i++)
		{
			// std::cout << "Angle[i]=" << Angle[i]<<std::endl;
			Difference_Angle[i] = sqrt(pow((Angle[i]-Angle[m_nNode]),2));
     		// std::cout << "Difference_Angle[i]=" << Difference_Angle[i] <<" "<< i <<std::endl;

			if(max < Difference_Angle[i])
			{
				max = Difference_Angle[i];
			}
			if((min > Difference_Angle[i])&&(m_nNode != i))
			{
				min = Difference_Angle[i];
			}
//			std::cout << "scaled_Angle[i]=" << scaled_Angle[i]<<std::endl;
		}

		double scaled_Angle[60];
		for (int i=1;i<60;i++)
		{
//			std::cout << "distance_from_consumer[i]=" << distance_from_consumer[i]<<std::endl;
			scaled_Angle[i] = (max-Difference_Angle[i])/(max - min);

		}
		scaled_Angle[0] = 0;//Angle From
		scaled_Angle[m_nNode] = 0;

		for (int i=0;i<60;i++)
			{
//				std::cout << "scaled_Angle[i]=" << scaled_Angle[i]<<std::endl;
			}
//				std::cout<<"+-+- \n";

//		Cache Availability
		double CacheAvailability[60];
		for (int i=0;i<60;i++)
		{
			CacheAvailability[i] = 1;
		}
		CacheAvailability[0] = 0;

		for (int i=0;i<60;i++)
		{
			// std::cout << "CacheAvailability[i]=" << CacheAvailability[i]<<std::endl;
		}

		std::cout << "\n m_nTime = " << m_nTime <<std::endl;

		if(m_nTime > 10000000)

/////////////////////////////// TOPSIS ?????????????????????????????//////////////////
	{

	  std::fstream fo12;
	  // opens an existing csv file or creates a new file
	  fo12.open("VoI.csv", std::ios::out | std::ios::app);
	  fo12 <<"Voi_NodeID_linear"<<", "<<m_nSeq << ", " << RecContent << ", "<< "\n";

		int parameters_n = 4; // Parameters of TOPSIS
		int veh_n = 60; // Number of Vehicles

		double v_p[parameters_n][veh_n];
		double v_p_norm[parameters_n][veh_n];
		double v_p_norm_divider = 0;
		double p_p[parameters_n];

		double max_p[parameters_n];
		double min_p[parameters_n];
		double S_p[parameters_n][veh_n];
		double S_n[parameters_n][veh_n];
		double S_star[veh_n], S_dash[veh_n];
		double Criteria_star[veh_n];
		double Criteria_dash[veh_n];

		for (int i=0; i<veh_n; i++)
		    {
            	v_p[0][i] = scaled_distance_from_consumer[i];
            	v_p[1][i] = scaled_Angle[i];
            	v_p[2][i] = CacheAvailability[i];
		        v_p[3][i] = scaled_velocity_difference_from_consumer[i];
		    }

	std::cout << "\n m_node = " << m_nNode <<std::endl;

		for (int i=0; i<parameters_n; i++)
		    {
		        for (int i1=0; i1<veh_n; i1++)
		        {
//		        	std::cout<<v_p[i][i1]<<" ";
		        }
//		        std::cout<<"\n";
		    }
//		std::cout<<"\n";

		int Proddd = ProdUcer;
		for (int i=0; i<parameters_n; i++)
		    {
		        for (int i1=0; i1<veh_n; i1++)
		        {
		            // cout<<" i1 i "<< i1 <<" "<< i <<" v_p[i1][i] "<<v_p[i1][i]<<"\n";
		            v_p_norm_divider = v_p_norm_divider + pow(v_p[i][i1],2)  ;
		        }
		            // cout<<"v_p_norm_divider "<<v_p_norm_divider<<"\n";
		            v_p_norm_divider = sqrt(v_p_norm_divider);
		            // std::cout<<"sqrt(v_p_norm_divider) = "<<v_p_norm_divider<<"\n";

		        for (uint32_t i1=0; i1<veh_n; i1++)
		        {
		            // cout<<" i1 i "<< i1 <<" "<< i <<" v_p[i1][i] "<<v_p[i1][i]<<"\n";
		        	if((i1 == Proddd)||(i1 == m_nNode))
		        	{
		        		v_p_norm[i][i1] = 0;
		        	}

		        	else{
		            v_p_norm[i][i1] = v_p[i][i1] / v_p_norm_divider;
		        	}
		            // cout<<" i1 i "<< i1 <<" "<< i <<" v_p_norm[i1][i] "<<v_p_norm[i1][i]<<"\n";
		        }
		        // cout<<" Coming Out \n \n";
		        v_p_norm_divider = 0;
		    }

		for (int i=0; i<parameters_n; i++)
		    {
		        for (int i1=0; i1<veh_n; i1++)
		        {
//		        	std::cout<<v_p_norm[i][i1]<<" ";
		        }
//		        std::cout<<"\n";
		    }

		for (int i1=0; i1<parameters_n; i1++)
		        {
		            p_p[i1] = 1;
		        }
		            p_p[0] = 0.25;
		            p_p[1] = 0.25;
		            p_p[2] = 0.25;
		            p_p[3] = 0.25;
		// std::cout<<"\n";

		for (int i1=0; i1<parameters_n; i1++)
		        {
					// std::cout<<p_p[i1]<<" ";
		            // std::cout<<"\n";
		        }

		// std::cout<<"\n";

		for (int i=0; i<parameters_n; i++)
		    {
		        for (int i1=0; i1<veh_n; i1++)
		        {
		            // cout<<"i1 i "<< i1 <<" "<< i <<" v_p_norm[i1][i] "<<v_p_norm[i1][i]<<" p_p[i1] "<<p_p[i]<<"\n";
		            v_p_norm[i][i1] = v_p_norm[i][i1] * p_p[i];
		            // cout<<"i1 i "<< i1 <<" "<< i <<" v_p_norm[i1][i] "<<v_p_norm[i1][i]<<" p_p[i1] "<<p_p[i]<<"\n";

		        }
		    }
		// cout<<"\n";

		for (int i=0; i<parameters_n; i++)
		    {
		        for (int i1=0; i1<veh_n; i1++)
		        {
//		        	 std::cout<<v_p_norm[i][i1]<<" ";
		        }
//		         std::cout<<"\n";
		    }
//		 std::cout<<"\n";


		for (int i=0; i<parameters_n; i++)
		    {
		        double max=0;
		        for (int i1 =0; i1<veh_n; i1++)
		        {
		                        // cout<<" i "<< i <<" min " <<min<<"\n";
		            if (v_p_norm[i][i1] > max)
		            max = v_p_norm[i][i1];
		        }
		        max_p[i] = max;
		        max = 0;
		        // std::cout<<" i "<< i <<" max_p[i] " <<max_p[i]<<"\n";
		    }
		// std::cout<<"\n";

		double min = 1000;
		for (int i=0; i<parameters_n; i++)
		    {
		        for (int i1 = 0; i1 < veh_n; i1++)
		        {
		            // cout<<" i "<< i <<" min " <<min<<"\n";
		            if (v_p_norm[i][i1] < min)
		            min = v_p_norm[i][i1];
		        }
		        min_p[i] = min;
		        min = 1000;
		        // std::cout<<" i "<< i <<" min_p[i] " <<min_p[i]<<"\n";
		    }

		// double S_p[parameters_n][veh_n];
		// std::cout<<"\n";
		for (int i=0; i<parameters_n; i++)
		    {
		        for (int i1 = 0; i1 < veh_n; i1++)
		        {
		            // cout<<" i "<< i <<" i1 "<< i1 <<" " <<max_p[i]<<" "<<v_p_norm[i][i1]<<"\n";

		            S_p[i][i1] = pow((v_p_norm[i][i1] - max_p[i]),2);
		            // std::cout<<" v_p_norm[i][i1] "<< v_p_norm[i][i1] <<" max_p[i] "<< max_p[i] <<" S_p[i][i1] " <<S_p[i][i1]<<"\n";
		        }
		        // min_p[i] = min;
		        // min = 1000;
		        // cout<<" i "<< i <<" min_p[i]" <<min_p[i]<<"\n";
		    }

		// double S_n[parameters_n][veh_n];
		// std::cout<<"\n"<< m_nNode <<"\n";
		for (int i=0; i<parameters_n; i++)
		    {
		        for (int i1 = 0; i1 < veh_n; i1++)
		        {
		            // cout<<" i "<< i <<" i1 "<< i1 <<" " <<min_p[i]<<" "<<v_p_norm[i][i1]<<"\n";
		            S_n[i][i1] = pow((v_p_norm[i][i1] - min_p[i]),2);
		            // std::cout<<" v_p_norm[i][i1] "<< v_p_norm[i][i1] <<" min_p[i] "<< min_p[i] <<" S_n[i][i1] " <<S_n[i][i1]<<"\n";
		        }
		        // min_p[i] = min;
		        // min = 1000;
		        // cout<<" i "<< i <<" min_p[i]" <<min_p[i]<<"\n";
		    }

		// std::cout<<"\n";
		for (int i=0; i<parameters_n; i++)
		    {
		        for (int i1 = 0; i1 < veh_n; i1++)
		        {
		        	// std::cout<<" S_n[i][i1] "<< S_n[i][i1] <<"\n";
		        }
		        // std::cout<<"\n";
		        // min_p[i] = min;
		        // min = 1000;
		        // cout<<" i "<< i <<" min_p[i]" <<min_p[i]<<"\n";
		    }

		// std::cout<<"\n";
		for (int i=0; i<parameters_n; i++)
		    {
		        for (int i1 = 0; i1 < veh_n; i1++)
		        {
		        	// std::cout<<" S_p[i][i1] "<< S_p[i][i1] <<"\n";
		        }
		        // std::cout<<"\n";
		        // min_p[i] = min;
		        // min = 1000;
		        // cout<<" i "<< i <<" min_p[i]" <<min_p[i]<<"\n";
		    }


		for (int i=0; i<veh_n; i++)
		    {
		        double sums = 0;
		        for (int i1 = 0; i1 < parameters_n; i1++)
		        {
		            sums = sums +  S_p[i1][i];
		            // cout<<" i1 "<< i1 <<" S_p[i1][i]" <<S_p[i1][i]<<"\n";
		        }
		            S_star[i] = sqrt(sums);
		            // sums = 0;
		            // cout<<"\n";
		            // std::cout<<" i "<< i <<" S_star[i]" <<S_star[i]<<"\n";
		            // cout<<"\n";
		    }

		for (int i=0; i<veh_n; i++)
		    {
		        double sums = 0;
		        for (int i1 = 0; i1 < parameters_n; i1++)
		        {
		            sums = sums + S_n[i1][i];
		            // cout<<" i1 "<< i1 <<" S_n[i1][i]" <<S_p[i1][i]<<"\n";
		        }
		            S_dash[i] = sqrt(sums);
		            // sums = 0;
		            // cout<<"\n";
		            // std::cout<<" i "<< i <<" S_dash[i]" <<S_dash[i]<<"\n";
		            // cout<<"\n";
		    }
		// std::cout<<"\n";
		    for (int i=0; i<veh_n; i++)
		    {

		        Criteria_star[i] = S_star[i] / (S_star[i]+S_dash[i]);
//		        // std::cout<<" i "<< i <<" Criteria_star[i] " <<Criteria_star[i]<<"\n";
		        // cout<<"\n";
		    }

		    for (int i=0; i<veh_n; i++)
		    {
		        Criteria_dash[i] = S_dash[i] / (S_star[i]+S_dash[i]);
//		         std::cout<<" i "<< i <<" Criteria_dash[i] " <<Criteria_dash[i]<<"\n";
//		         std::cout<<"\n";
		    }

		    int best_ID = -1;
		    double max=0;
		        for (int i1 =0; i1<veh_n; i1++)
		        {
		            if (Criteria_dash[i1] > max)
		            {
		                max = Criteria_dash[i1];
		                best_ID = i1;
		            }
		        }

		        RecommendM[best_ID] = RecContent;
////		        int RecommendedContent;
//		        if(m_nSeq!=51)
//		        {
//		        	RecommendM[best_ID] = m_nSeq + 1; //Sequence Number Yet to be Called
//		        }
//		        else
//		        {
//		        	RecommendM[best_ID] = 1; //Starting from 1 to 51
//		        }
		        std::cout<<"\n";
		        std::cout<<" Best Prefetcher for Node " << m_nNode << " with Seq No " << m_nSeq << " is " << best_ID<< " with content sequence "<< RecContent <<"\n";
		        std::cout<<"\n";
		}
}

void VoI_Calc::getRecommendedDataFromNode(uint32_t nNode, uint32_t nSeq, double nTime)
{
		m_nNode = nNode;
		m_nSeq = nSeq;
		m_nTime = nTime;

		m_Cou_Seq [m_nNode][m_nSeq] = m_Cou_Seq [m_nNode][m_nSeq] +1 ;

		if(m_Cou_Seq [m_nNode][m_nSeq] == 1)
		{
			m_Previous_Time_Seq_ID [m_nNode][m_nSeq] = m_nTime;
		}
		else
		{
			m_Previous_Time_Seq_ID [m_nNode][m_nSeq] = m_Current_Time_Seq_ID [m_nNode][m_nSeq];
		}
		m_Current_Time_Seq_ID [m_nNode][m_nSeq] = m_nTime;

////		VOI Calculation
		Yi[m_nNode][m_nSeq] = (double)(m_Current_Time_Seq_ID [m_nNode][m_nSeq]/1000000) - (double)(m_Previous_Time_Seq_ID [m_nNode][m_nSeq]/1000000) ;

		for (int i = 0; i<5; i++)
			{
			for (int i1 = 1; i1<51; i1++)
				{
				Zi[i][i1] = (double)(m_nTime/1000000) - (double)(m_Current_Time_Seq_ID[i][i1]/1000000);
				Voi_NodeID_linear [i][i1] = (0.5)*((1/(1+(Yi[i][i1] /m_Cou_Seq[i][i1])))+(1/(1+(Zi[i][i1]/m_Cou_Seq[i][i1]))));
				Voi_NodeID_Exponential [i][i1] = (0.5)*((exp(-Yi[i][i1] /m_Cou_Seq[i][i1]))+(exp(-Zi[i][i1]/m_Cou_Seq[i][i1])));
				Voi_NodeID_Logrithamic [i][i1] = (0.5)*((1/log2((Yi[i][i1] /m_Cou_Seq[i][i1])+2))+(1/log2((Zi[i][i1]/m_Cou_Seq[i][i1])+2)));
				}
			}
}

void VoI_Calc::getVelocityUpdate(uint32_t nNode,double x, double y, double z, double x1, double y1, double z1)
{
	std::cout << "--- OLA ---x=" << x << ", y=" << y << ", z=" << z <<" at " << m_nNode <<std::endl;
	m_nNode = nNode;
	nodeVelocity[0][m_nNode] = x1;
	nodeVelocity[1][m_nNode] = y1;
	nodeVelocity[2][m_nNode] = z1;

	nodeLocatOld[0][m_nNode] = nodeLocatNew[0][m_nNode];
	nodeLocatOld[1][m_nNode] = nodeLocatNew[1][m_nNode];
	nodeLocatOld[2][m_nNode] = nodeLocatNew[2][m_nNode];

	nodeLocatNew[0][m_nNode] = x;
	nodeLocatNew[1][m_nNode] = y;
	nodeLocatNew[2][m_nNode] = z;

	std::cout<<"\n";
	std::cout<<" < - - - - - - Location & Speed Updated - - - - - - > "<< nNode;
	std::cout<<"\n";

}


int VoI_Calc::RecommendMessage(uint32_t m_nNode)
{
//	NS_LOG_INFO("<<<<<<<<<2<<<<<<<<In_Voi");

	if(RecommendM[m_nNode]>0)
	{
		int val = RecommendM[m_nNode];
//		NS_LOG_INFO("<<<<<<<<<<<<<< Is Here <<<<<<<<<<<<!!!!!!!!!!!!!!!!!!!In_Voi");

		RecommendM[m_nNode] = 0;
		return val;
	}
	else
	{
		return 0;
	}

}

double VoI_Calc::CorrelationCoefficient(double X[], double Y[], int n)
{

	double sum_X = 0, sum_Y = 0, sum_XY = 0;
	double squareSum_X = 0, squareSum_Y = 0;

    for (int i = 0; i < n; i++)
    {
        // sum of elements of array X.
        sum_X = sum_X + X[i];
        // sum of elements of array Y.
        sum_Y = sum_Y + Y[i];

        // sum of X[i] * Y[i].
        sum_XY = sum_XY + X[i] * Y[i];

        // sum of square of array elements.
        squareSum_X = squareSum_X + X[i] * X[i];
        squareSum_Y = squareSum_Y + Y[i] * Y[i];
    }

    // use formula for calculating correlation coefficient.
    double corr = (double)(n * sum_XY - sum_X * sum_Y)
                  / sqrt((n * squareSum_X - sum_X * sum_X)
                      * (n * squareSum_Y - sum_Y * sum_Y));
    return corr;
}

void VoI_Calc::SendingTimeSet(uint32_t nNode, uint32_t nSeq, double nTime)
	{
		m_I_time[nNode][nSeq] = nTime/1000000; //For Calculating Delay
	}

double VoI_Calc::FetchingTimeSet(uint32_t nNode1111, uint32_t nSeq1111)
{
	double val = m_I_time[nNode1111][nSeq1111];
	return val;
}

} // namespace ndn
} // namespace ns3
