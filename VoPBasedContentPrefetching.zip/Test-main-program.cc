/* -*- Mode:C++; c-file-style:"gnu"; indent-tabs-mode:nil; -*- */
/**
 * Copyright (c) 1011-1015  Regents of the University of California.
 *
 * This file is part of ndnSIM. See AUTHORS for complete list of ndnSIM authors and
 * contributors.
 *
 * ndnSIM is free software: you can redistribute it and/or modify it under the terms
 * of the GNU General Public License as published by the Free Software Foundation,
 * either version 3 of the License, or (at your option) any later version.
 *
 * ndnSIM is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
 * without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
 * PURPOSE.  See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along with
 * ndnSIM, e.g., in COPYING.md file.  If not, see <http://www.gnu.org/licenses/>.
 **/

// ndn-simple.cpp

#include "ns3/core-module.h"
#include "ns3/network-module.h"
#include "ns3/point-to-point-module.h"
#include "ns3/ndnSIM-module.h"
#include "ns3/core-module.h"
#include "ns3/network-module.h"
#include "ns3/point-to-point-module.h"
#include "ns3/ndnSIM-module.h"
#include "ns3/core-module.h"
#include "ns3/network-module.h"
#include "ns3/internet-module.h"
#include "ns3/mobility-module.h"
#include "ns3/aodv-module.h"
#include "ns3/olsr-module.h"
#include "ns3/dsdv-module.h"
#include "ns3/dsr-module.h"
#include "ns3/applications-module.h"
#include "ns3/itu-r-1411-los-propagation-loss-model.h"
#include "ns3/ocb-wifi-mac.h"
#include "ns3/wifi-80211p-helper.h"
#include "ns3/wave-mac-helper.h"
#include "ns3/flow-monitor-module.h"
#include "ns3/config-store-module.h"
#include "ns3/integer.h"
#include "ns3/wave-bsm-helper.h"
#include "ns3/wave-helper.h"
#include "ns3/yans-wifi-helper.h"
#include "ns3/netanim-module.h"
#include "ns3/tag.h"
#include "ns3/seq-ts-header.h"
#include "ns3/ipv4-header.h"


namespace ns3 {


/**
 * This scenario simulates a very simple network topology:
 *
 *
 *      +----------+     1Mbps      +--------+     1Mbps      +----------+
 *      | consumer | <------------> | router | <------------> | producer |
 *      +----------+         10ms   +--------+          10ms  +----------+
 *
 *
 * Consumer requests data from producer with frequency 10 interests per second
 * (interests contain constantly increasing sequence number).
 *
 * For every received interest, producer replies with a data packet, containing
 * 1024 bytes of virtual payload.
 *
 * To run scenario and see what is happening, use the following command:
 *
 *     NS_LOG=ndn.Consumer:ndn.Producer ./waf --run=ndn-simple
 */


//Change in MAin file Number of consumers
//Change in ndn- consumer new @   if ((n_ID>0)&&(n_ID<26)) //1-15 are consumers
//Change in voi-calculation [Content][Nodes] Number of


int
main(int argc, char* argv[])
{
  // setting default parameters for PointToPoint links and channels

  // Read optional command-line parameters (e.g., enable visualizer with ./waf --run=<> --visualize
  CommandLine cmd;
  cmd.Parse(argc, argv);

  // Creating nodes
  NodeContainer consumers1, consumers2, producer, forwarders;
  producer.Create(1);
  consumers1.Create(12);
  consumers2.Create(13); // 55
  forwarders.Create(34); // 24


  std::string m_lossModelName = "ns3::TwoRayGroundPropagationLossModel";
  std::string m_phyMode = "OfdmRate6MbpsBW10MHz";
  // frequency
  double freq = 5.9e9;

  // Setup propagation models
  YansWifiChannelHelper wifiChannel;
  wifiChannel.SetPropagationDelay ("ns3::ConstantSpeedPropagationDelayModel");

  // two-ray requires antenna height (else defaults to Friss)
  wifiChannel.AddPropagationLoss (m_lossModelName, "Frequency", DoubleValue (freq), "HeightAboveZ", DoubleValue (1.5));

 //  // if no obstacle model, then use Nakagami fading if requested
 //  wifiChannel.AddPropagationLoss ("ns3::NakagamiPropagationLossModel");


   // the channel
   Ptr<YansWifiChannel> channel = wifiChannel.Create ();

   // The below set of helpers will help us to put together the wifi NICs we want
   YansWifiPhyHelper wifiPhy =  YansWifiPhyHelper::Default ();
   wifiPhy.SetChannel (channel);
   // ns-3 supports generate a pcap trace
   wifiPhy.SetPcapDataLinkType (WifiPhyHelper::DLT_IEEE802_11);

   YansWavePhyHelper wavePhy =  YansWavePhyHelper::Default ();
   wavePhy.SetChannel (channel);
   wavePhy.SetPcapDataLinkType (WifiPhyHelper::DLT_IEEE802_11);

   // Setup WAVE PHY and MAC
   NqosWaveMacHelper wifi80211pMac = NqosWaveMacHelper::Default ();
   WaveHelper waveHelper = WaveHelper::Default ();
   Wifi80211pHelper wifi80211p = Wifi80211pHelper::Default ();

   // Setup 802.11p stuff
   wifi80211p.SetRemoteStationManager ("ns3::ConstantRateWifiManager",
                                       "DataMode",StringValue (m_phyMode),
                                       "ControlMode",StringValue (m_phyMode));

   // Setup WAVE-PHY stuff
   waveHelper.SetRemoteStationManager ("ns3::ConstantRateWifiManager",
                                       "DataMode",StringValue (m_phyMode),
                                       "ControlMode",StringValue (m_phyMode));

   // Set Tx Power
   wifiPhy.Set ("TxPowerStart",DoubleValue (23));
   wifiPhy.Set ("TxPowerEnd", DoubleValue (23));

   wavePhy.Set ("TxPowerStart",DoubleValue (23));
   wavePhy.Set ("TxPowerEnd", DoubleValue (23));

   // Add an upper mac and disable rate control
   WifiMacHelper wifiMac;
   wifiMac.SetType ("ns3::AdhocWifiMac");
   QosWaveMacHelper waveMac = QosWaveMacHelper::Default ();

   wifi80211p.Install (wifiPhy, wifi80211pMac, consumers1);
   wifi80211p.Install (wifiPhy, wifi80211pMac, consumers2);
   wifi80211p.Install (wifiPhy, wifi80211pMac, producer);
   wifi80211p.Install (wifiPhy, wifi80211pMac, forwarders);

   MobilityHelper mobilityAdhoc;

    // Node Position
    ObjectFactory pos;
    pos.SetTypeId ("ns3::RandomBoxPositionAllocator");
    pos.Set ("X", StringValue ("ns3::UniformRandomVariable[Min=0.0|Max=1500.0]"));
    pos.Set ("Y", StringValue ("ns3::UniformRandomVariable[Min=0.0|Max=300.0]"));
    // we need antenna height uniform [1.0 .. 2.0] for loss model
    pos.Set ("Z", StringValue ("ns3::UniformRandomVariable[Min=1.0|Max=2.0]"));

    Ptr<PositionAllocator> taPositionAlloc = pos.Create ()->GetObject<PositionAllocator> ();

    // Node Speed
    std::stringstream ssSpeed;
    ssSpeed << "ns3::UniformRandomVariable[Min=0.0|Max=50.0]";
    std::stringstream ssPause;
    ssPause << "ns3::ConstantRandomVariable[Constant=0]";
    mobilityAdhoc.SetMobilityModel ("ns3::RandomWaypointMobilityModel",
                                    "Speed", StringValue (ssSpeed.str ()),
                                    "Pause", StringValue (ssPause.str ()),
                                    "PositionAllocator", PointerValue (taPositionAlloc));
    mobilityAdhoc.SetPositionAllocator (taPositionAlloc);
    mobilityAdhoc.Install (producer);
    mobilityAdhoc.Install (consumers1);
    mobilityAdhoc.Install (forwarders);
    mobilityAdhoc.Install (consumers2);


//*--------------------------------------------------------------------------*/
//  Connecting nodes using two links
//  PointToPointHelper p2p;
//  p2p.Install(nodes.Get(0), nodes.Get(1));
//  p2p.Install(nodes.Get(1), nodes.Get(2));
//  p2p.Install(nodes.Get(2), nodes.Get(3));
//  p2p.Install(nodes.Get(3), nodes.Get(4));
//  p2p.Install(nodes.Get(0), nodes.Get(3));
//  p2p.Install(nodes.Get(3), nodes.Get(0));
//  MobilityHelper mobility;
//  mobility.SetPositionAllocator ("ns3::GridPositionAllocator",
//                                 "MinX", DoubleValue (1.0),
//                                 "MinY", DoubleValue (1.0),
//                                 "DeltaX", DoubleValue (5.0),
//                                 "DeltaY", DoubleValue (5.0),
//                                 "GridWidth", UintegerValue (3),
//                                 "LayoutType", StringValue ("RowFirst"));
//  mobility.SetMobilityModel ("ns3::RandomWalk2dMobilityModel",
//                             "Mode", StringValue ("Time"),
//                             "Time", StringValue ("0.2s"),
//                             "Speed", StringValue ("ns3::ConstantRandomVariable[Constant=1.0]"),
//                             "Bounds", RectangleValue (Rectangle (0.0, 100.0, 0.0, 100.0)));
//  mobility.Install(nodes);

//  MobilityHelper mobility;
//  // setup the grid itself: objects are laid out
//  // started from (-100,-100) with 10 objects per row,
//  // the x interval between each object is 5 meters
//  // and the y interval between each object is 10 meters
//  mobility.SetPositionAllocator ("ns3::GridPositionAllocator",
//                                 "MinX", DoubleValue (0),
//                                 "MinY", DoubleValue (0),
//                                 "DeltaX", DoubleValue (70),
//                                 "DeltaY", DoubleValue (10),
//                                 "GridWidth", UintegerValue (10),
//                                 "LayoutType", StringValue ("RowFirst"));
//  // each object will be attached a static position.
//  // i.e., once set by the "position allocator", the
//  // position will never change.
//  mobility.SetMobilityModel ("ns3::ConstantPositionMobilityModel");////////////////////////////
//
//  // finalize the setup by attaching to each object
//  // in the input array a position and initializing
//  // this position with the calculated coordinates.
//
//  // 2. Install Mobility model
//  mobility.Install(nodes);
//  // Install NDN stack on all nodes
//  ndn::StackHelper ndnHelper;
//  ndnHelper.setPolicy("nfd::cs::lru");
//  ndnHelper.SetDefaultRoutes(true);
//  ndnHelper.InstallAll();

  // Install Ndn stack on all nodes
  ndn::StackHelper ndnHelper;
  ndnHelper.SetDefaultRoutes(true);
  ndnHelper.setCsSize(100); // allow just 100 entries to be cached
  ndnHelper.setPolicy("nfd::cs::lru");
  ndnHelper.InstallAll();

 // Choosing forwarding strategy
 // ndn::StrategyChoiceHelper::InstallAll("/ndn/multicast", "/localhost/nfd/strategy/multicast");
 ndn::StrategyChoiceHelper::InstallAll("/monet", "/localhost/nfd/strategy/multicast");


  // Installing applications

  // Consumer1
 ndn::AppHelper consumerHelper1("ns3::ndn::ConsumerCbrTwo");
 // Consumer will request /prefix/0, /prefix/1, ...
 consumerHelper1.SetPrefix("/monet");
 consumerHelper1.SetAttribute("Frequency", StringValue("5")); // 10 interests a second
 auto apps1 = consumerHelper1.Install(consumers1);// second node
 apps1.Start(Seconds(0.01));
 apps1.Stop(Seconds(100.0)); // stop the consumer app at 10 seconds mark

  // Producer1
  ndn::AppHelper producerHelper1("ns3::ndn::Producer");
  // Producer will reply to all requests starting with /prefix
  producerHelper1.SetPrefix("/monet");
  producerHelper1.SetAttribute("Freshness", TimeValue(Seconds(0.5))); // freshness 2 seconds (!!!
  producerHelper1.SetAttribute("PayloadSize", StringValue("1024"));
  producerHelper1.Install(producer); // last node

  // Consumer
  ndn::AppHelper consumerHelper3("ns3::ndn::ConsumerRelay");
  // Consumer will request /prefix/0, /prefix/1, ...
  consumerHelper3.SetPrefix("/monet");
  consumerHelper3.SetAttribute("Frequency", StringValue("4")); // 10 interests a second
  auto apps3 = consumerHelper3.Install(forwarders);                        // first node
  apps3.Start(Seconds(0.00));
  apps3.Stop(Seconds(100.0)); // stop the consumer app at 10 seconds mark

 // Consumer2
 	ndn::AppHelper consumerHelper2("ns3::ndn::ConsumerCbrTwo");
 	// Consumer will request /prefix/0, /prefix/1, ...
 	consumerHelper2.SetPrefix("/monet");
 	consumerHelper2.SetAttribute("Frequency", StringValue("5")); // 10 interests a second
	auto apps2 = consumerHelper2.Install(consumers2);// second node
	apps2.Start(Seconds(0.01));
	apps2.Stop(Seconds(100.0)); //

  Simulator::Stop(Seconds(100.0));

  Simulator::Run();
  Simulator::Destroy();

  return 0;
}

} // namespace ns3

int
main(int argc, char* argv[])
{
  return ns3::main(argc, argv);
}
