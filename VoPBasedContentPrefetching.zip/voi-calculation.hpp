/* -*- Mode:C++; c-file-style:"gnu"; indent-tabs-mode:nil; -*- */
/**
 * Copyright (c) 2011-2015  Regents of the University of California.
 *
 * This file is part of ndnSIM. See AUTHORS for complete list of ndnSIM authors and
 * contributors.
 *
 * ndnSIM is free software: you can redistribute it and/or modify it under the terms
 * of the GNU General Public License as published by the Free Software Foundation,
 * either version 3 of the License, or (at your option) any later version.
 *
 * ndnSIM is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
 * without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
 * PURPOSE.  See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along with
 * ndnSIM, e.g., in COPYING.md file.  If not, see <http://www.gnu.org/licenses/>.
 **/

#include "ns3/log.h"
#include "ns3/assert.h"
#include "ns3/packet.h"
#include "ns3/uinteger.h"
#include "ns3/integer.h"
#include "ns3/double.h"
#include "ns3/math.h"
#include <cmath>
#include "math.h"
#include "ns3/log.h"
#include <vector>
#include <algorithm>
#include <iterator>
#include <cmath>
#include <functional>
#include <algorithm>
#include <stdint.h>
#include <utility>
#include <queue>
#include <stdlib.h>
#include <stdio.h>
#include <vector>
#include "ns3/core-module.h"
#include "ns3/network-module.h"
#include "ns3/mobility-module.h"

//#include "eigen/Eigen/Core"
//#include "clustering/lib/SpectralClustering.h"

#include "model/ndn-l3-protocol.hpp"
#include "model/ndn-app-link-service.hpp"
#include "model/null-transport.hpp"

#ifndef VOI_CALCULAION_H
#define VOI_CALCULAION_H

//namespace alglib {
namespace ns3 {
namespace ndn {

class VoI_Calc{

public:

//	uint32_t	m_nNode; // number of nodes
//	uint32_t	m_nSeq; // number of nodes
//	uint32_t	m_nTime; // number of nodes
//	uint32_t	m_Cou_Seq[100][10]; // [Content][Nodes]
//	uint32_t	m_Cr_Time_Seq_ID[100][10]; // [Content][Nodes]
//	uint32_t	m_Pr_Time_Seq_ID[100][10]; // [Content][Nodes]
	void getDataFromNode(uint32_t nNode, uint32_t nSeq, double nTime, double x, double y, double z,double x10, double y10, double z10);
	void DataFromNode(uint32_t nNode, uint32_t nSeq, double nTime, double x, double y, double z);
	double CorrelationCoefficient(double X[], double Y[], int n);
	void LocationCoordinate(double x, double y, double z, uint32_t m_nNode);
	void getVelocityUpdate(uint32_t nNode, uint32_t nSeq, double nTime, double x, double y, double z);
	void getRecommendedDataFromNode(uint32_t nNode, uint32_t nSeq, double nTime);
	void getVelocityUpdate(uint32_t nNode,double x, double y, double z, double x1, double y1, double z1);
	void SendingTimeSet(uint32_t nNode, uint32_t nSeq, double nTime);
	double FetchingTimeSet(uint32_t nNode, uint32_t nSeq);


	int RecommendMessage(uint32_t m_nNode);
//
//extern	int Num_of_Vehicles = 5;
//extern	int Content_Numbers = 50;

//	VoI_Calc();
//	~VoI_Calc(){};
};

/**
 * @ingroup ndn-apps
 * @brief A simple Interest-sink applia simple Interest-sink application
 *
 * A simple Interest-sink applia simple Interest-sink application,
 * which replying every incoming Interest with Data packet with a specified
 * size and name same as in Interest.cation, which replying every incoming Interest
 * with Data packet with a specified size and name same as in Interest.
 */


//)
} // namespace ndn
} // namespace ns3

#endif // NDN_PRODUCER_H
